import{b as r}from"./_baseUniq-BHVHCXjC.js";var e=4;function a(o){return r(o,e)}export{a as c};
